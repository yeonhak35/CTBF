---
linkTitle: Documentation
title: Introduction
---

👋 Welcome to the demo of the Hugo Blox Documentation template!

<!--more-->

This site is a demo of the Hugo Blox Documentation theme. For the full documentation on how to use this template, refer to the [Hugo Blox Documentation](https://docs.hugoblox.com/).

## Next

{{< cards >}}
  {{< card url="getting-started" title="Get Started" icon="document-text" subtitle="Create your docs in just 5 minutes!" >}}
{{< /cards >}}
